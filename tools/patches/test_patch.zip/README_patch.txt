Test patch for Depth of Dejenol
Version: 1.0.1-test

This file is included in the test patch used by the updater.
