﻿using CommunityToolkit.Mvvm.Messaging;
using Mordorings.Messages;

namespace Mordorings.ViewModels;

public partial class EditMenuViewModel(IViewModelFactory factory)
{
    [RelayCommand]
    private void OpenEditMonster()
    {
        WeakReferenceMessenger.Default.Send(new ViewContentChangedMessage(factory.CreateViewModel<EditMonstersViewModel>()));
    }
}
