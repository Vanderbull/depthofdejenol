﻿namespace Mordorings.ViewModels.Abstractions;

public interface IViewModel
{
    string Instructions { get; }
}
