﻿namespace Mordorings;

public static class FloorExtensions
{
    public static int? GetAreaNumFromTile(this Floor floor, Tile? tile)
    {
        if (tile is null)
            return null;
        if (tile.X is < 0 or >= Game.FloorWidth || tile.Y is < 0 or >= Game.FloorHeight)
            return null;
        return floor.Tiles[tile.X + tile.Y * Game.FloorHeight].Area;
    }

    public static Area? GetAreaFromTile(this Floor floor, Tile tile)
    {
        int? areaNum = floor.GetAreaNumFromTile(tile);
        if (areaNum is null)
            return null;
        return floor.Areas[areaNum.Value];
    }

    public static IEnumerable<Tile> GetTilesForArea(this Floor floor, Tile tile)
    {
        int? areaNum = floor.GetAreaNumFromTile(tile);
        if (areaNum is null)
            yield break;
        for (int x = 0; x < Game.FloorWidth; x++)
        {
            for (int y = 0; y < Game.FloorHeight; y++)
            {
                if (floor.Tiles[x + y * Game.FloorHeight].Area == areaNum)
                {
                    yield return new Tile(x, y);
                }
            }
        }
    }
}
