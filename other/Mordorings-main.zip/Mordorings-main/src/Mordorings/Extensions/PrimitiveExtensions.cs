﻿namespace Mordorings;

public static class PrimitiveExtensions
{
    public static bool HasTileFlag(this long val, DungeonTileFlag flag) =>
        (val & (long)flag) != 0;
}
