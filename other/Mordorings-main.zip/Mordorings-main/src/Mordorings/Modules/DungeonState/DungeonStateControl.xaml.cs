﻿namespace Mordorings.Modules;

public partial class DungeonStateControl
{
    public DungeonStateControl()
    {
        InitializeComponent();
    }
}
