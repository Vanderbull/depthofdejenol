﻿namespace Mordorings.Modules;

public partial class GuildSpellsControl
{
    public GuildSpellsControl()
    {
        InitializeComponent();
    }
}
