﻿using Mapster;

namespace Mordorings.Modules;

public partial class EditMonsterModel
{
    private readonly Monster _monster;

    public EditMonsterModel(Monster monster)
    {
        _monster = monster;
        Initialize();
    }

    private void Initialize()
    {
        _monster.Adapt(this);
    }

    public static void Map()
    {
        TypeAdapterConfig<Monster, EditMonsterModel>.NewConfig()
                                                    .Map(monster => monster.Name, monster => monster.Name)
                                                    .Map(monster => monster.Attack, monster => monster.Attack)
                                                    .Map(monster => monster.Defense, monster => monster.Defense)
                                                    .Map(monster => monster.MonsterId, monster => monster.Id)
                                                    .Map(monster => monster.Hits, monster => monster.Hits)
                                                    .Map(monster => monster.NumGroups, monster => monster.NumGroups)
                                                    .Map(monster => monster.GroupSize, monster => monster.GroupSize)
                                                    .Map(monster => monster.PicId, monster => monster.PicId)
                                                    .Map(monster => monster.LevelFound, monster => monster.LevelFound)
                                                    .Map(monster => monster.EncounterChance, monster => monster.EncounterChance)
                                                    .Map(monster => monster.DamageMod, monster => monster.DamageMod)
                                                    .Map(monster => monster.Size, monster => monster.Size)
                                                    .Map(monster => monster.MonsterSubtype, monster => monster.MonsterSubtype)
                                                    .Map(monster => monster.GuildLevel, monster => monster.GuildLevel)
                                                    .Map(monster => monster.Alignment, monster => monster.Alignment)
                                                    .Map(monster => monster.BoxChance, monster => monster.BoxChance[1])
                                                    .Map(monster => monster.ChestChance, monster => monster.BoxChance[2])
                                                    .Map(monster => monster.LockedChance, monster => monster.LockedChance)
                                                    .Map(monster => monster.Strength, monster => monster.Stats[0])
                                                    .Map(monster => monster.Constitution, monster => monster.Stats[3])
                                                    .Map(monster => monster.Dexterity, monster => monster.Stats[5])
                                                    .Map(monster => monster.Spells, monster => monster.Attack);
    }
}
