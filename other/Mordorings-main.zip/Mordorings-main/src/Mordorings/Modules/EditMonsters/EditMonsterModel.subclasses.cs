﻿namespace Mordorings.Modules;

public partial class EditMonsterModel
{
    public class Resists
    {
        public int Fire { get; set; }

        public int Cold { get; set; }

        public int Electrical { get; set; }

        public int Mind { get; set; }

        public int Disease { get; set; }

        public int Poison { get; set; }

        public int Magic { get; set; }

        public int Stone { get; set; }

        public int Paralysis { get; set; }

        public int Drain { get; set; }

        public int Acid { get; set; }
    }

    public class SpecialProperties
    {
        public bool SeeInvisible { get; set; }

        public bool Invisible { get; set; }

        public bool MagicImmune { get; set; }

        public bool CharmResistant { get; set; }

        public bool WeaponResistant { get; set; }

        public bool WeaponImmune { get; set; }
    }

    public class SpecialAttacks
    {
        public bool Poison { get; set; }

        public bool Disease { get; set; }

        public bool Paralyze { get; set; }

        public bool BreatheFire { get; set; }

        public bool BreatheCold { get; set; }

        public bool Acid { get; set; }

        public bool Electrocute { get; set; }

        public bool Drain { get; set; }

        public bool Stone { get; set; }

        public bool Age { get; set; }

        public bool CriticalHit { get; set; }

        public bool Backstab { get; set; }

        public bool DestroyItem { get; set; }

        public bool Steal { get; set; }
    }

    public class CastSpells
    {
        public bool Fire { get; set; }

        public bool Cold { get; set; }

        public bool Electrical { get; set; }

        public bool Mind { get; set; }

        public bool Damage { get; set; }

        public bool Element { get; set; }

        public bool Kill { get; set; }
    }

    public record Sizes(short SizeId, string Description);
}
