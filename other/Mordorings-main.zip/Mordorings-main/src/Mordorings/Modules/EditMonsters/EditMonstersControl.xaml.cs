﻿namespace Mordorings.Modules;

public partial class EditMonstersControl
{
    public EditMonstersControl()
    {
        InitializeComponent();
    }
}
