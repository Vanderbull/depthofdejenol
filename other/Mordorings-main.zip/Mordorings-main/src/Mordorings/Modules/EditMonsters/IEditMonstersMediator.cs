﻿namespace Mordorings.Modules;

public interface IEditMonstersMediator
{
    IEnumerable<MonsterSubtypeGroup> GetMonsterGroups();
}

public class MonsterSubtypeGroup
{
    public int SubtypeId { get; init; }

    public string SubtypeName { get; init; } = string.Empty;

    public ObservableCollection<Monster> Monsters { get; set; } = [];
}
