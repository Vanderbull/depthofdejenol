﻿namespace Mordorings.Modules;

public class EditMonstersPresenter(IMordorIoFactory ioFactory) : IEditMonstersMediator
{
    public IEnumerable<MonsterSubtypeGroup> GetMonsterGroups()
    {
        MordorRecordReader reader = ioFactory.GetReader();
        Monster[] monsters = reader.GetMordorRecord<DATA05Monsters>().MonstersList;
        List<MonsterSubtypeIndexed> subtypes = reader.GetMordorRecord<DATA01GameData>().GetIndexedMonsterSubtypes().ToList();
        return monsters.GroupBy(monster => monster.MonsterSubtype)
                       .Select(grouping => new MonsterSubtypeGroup
                       {
                           SubtypeId = grouping.Key,
                           SubtypeName = subtypes.First(subtype => subtype.Index == grouping.Key).Name,
                           Monsters = new ObservableCollection<Monster>(grouping.OrderBy(monster => monster.GuildLevel))
                       })
                       .OrderBy(group => group.SubtypeId);
    }
}
