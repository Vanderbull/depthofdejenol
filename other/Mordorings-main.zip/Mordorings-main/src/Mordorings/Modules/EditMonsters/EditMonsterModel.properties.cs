﻿namespace Mordorings.Modules;

public partial class EditMonsterModel : ObservableValidator
{
    [MaxLength(30)]
    public string Name { get; set; } = null!;

    public int Attack { get; set; }

    public int Defense { get; set; }

    public int MonsterId { get; set; }

    public int Hits { get; set; }

    public int NumGroups { get; set; }

    public int GroupSize { get; set; }

    public int PicId { get; set; }

    public int LevelFound { get; set; }

    public int EncounterChance { get; set; }

    public double DamageMod { get; set; }

    public int Size { get; set; }

    public int MonsterSubtype { get; set; }

    public int GuildLevel { get; set; }

    public int Alignment { get; set; }

    public int BoxChance { get; set; }

    public int ChestChance { get; set; }

    public int LockedChance { get; set; }

    public int Strength { get; set; }

    public int Constitution { get; set; }

    public int Dexterity { get; set; }

    public Resists Resistances { get; } = new();

    public SpecialProperties Properties { get; } = new();

    public SpecialAttacks Attacks { get; } = new();

    public CastSpells Spells { get; } = new();
}
