﻿namespace Mordorings.Modules;

public partial class EditMonstersViewModel(IEditMonstersMediator mediator) : ViewModelBase
{
    public ObservableCollection<MonsterSubtypeGroup> MonsterTypes { get; } = new(mediator.GetMonsterGroups());

    private EditMonsterModel? _model;

    public EditMonsterModel? Model
    {
        get => _model;
        private set => SetProperty(ref _model, value);
    }

    [RelayCommand]
    private void LoadMonster(object? args)
    {
        Monster? monster = MonsterEventConversion.GetMonsterFromEvent(args);
        if (monster == null)
            return;
        Model = new EditMonsterModel(monster);
    }

    public override string Instructions => "Edit monster properties and stats. Not functional yet.";
}
