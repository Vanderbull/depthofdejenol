﻿namespace Mordorings.Modules;

public partial class MonsterHeatMapControl
{
    public MonsterHeatMapControl()
    {
        InitializeComponent();
    }
}
