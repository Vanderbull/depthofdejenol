﻿namespace Mordorings.Modules;

public partial class LevelRequirementsControl
{
    public LevelRequirementsControl()
    {
        InitializeComponent();
    }
}
