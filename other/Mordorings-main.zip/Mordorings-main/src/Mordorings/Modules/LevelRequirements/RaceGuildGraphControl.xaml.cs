﻿namespace Mordorings.Modules;

public partial class RaceGuildGraphControl
{
    public RaceGuildGraphControl()
    {
        InitializeComponent();
    }
}
