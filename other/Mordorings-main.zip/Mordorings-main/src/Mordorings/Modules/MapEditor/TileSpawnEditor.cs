﻿namespace Mordorings.Modules;

public class TileSpawnEditor : ObservableObject
{
    private Area? _currentArea;
    private Tile? _currentTile;

    public event EventHandler<TileSpawnChangedEventArgs>? FlagChanged;

    public void Initialize(List<Monster> monsters, List<MonsterSubtypeIndexed> indexedSubtypes)
    {
        Monsters = monsters;
        List<AreaSpawnMonsterSubtype> subtypes = [];
        foreach (AreaSpawnMonsterSubtype subtype in indexedSubtypes.Select(subtype => new AreaSpawnMonsterSubtype(subtype.Name, subtype.Index)))
        {
            subtype.SelectedChanged += (sender, _) =>
            {
                if (sender == null || _currentArea == null || _currentTile == null)
                    return;
                var area = (AreaSpawnMonsterSubtype)sender;
                if (area.Selected)
                {
                    _currentArea.SpawnMask |= 1 << area.MonsterSubtypeId;
                }
                else
                {
                    _currentArea.SpawnMask &= ~(1 << area.MonsterSubtypeId);
                }
                InvokeTileSpawnChangedEvent();
            };
            subtypes.Add(subtype);
        }
        MonsterSubtypes = subtypes;
    }

    private bool _laired;

    public bool Laired
    {
        get => _laired;
        set => SetProperty(ref _laired, value);
    }

    public void LoadTile(Tile tile, DungeonFloor selectedFloor)
    {
        _currentTile = tile;
        _currentArea = selectedFloor.Floor.GetAreaFromTile(tile);
        if (_currentArea == null)
            return;
        if (_currentArea.LairId > 0)
        {
            Laired = true;
            LairedMonster = Monsters.First(monster => monster.Id == _currentArea.LairId);
        }
        else
        {
            Laired = false;
            LairedMonster = null;
        }
        foreach (AreaSpawnMonsterSubtype subtype in MonsterSubtypes)
        {
            subtype.Selected = (_currentArea.SpawnMask & 1 << subtype.MonsterSubtypeId) != 0;
        }
        InvokeTileSpawnChangedEvent();
    }

    private void InvokeTileSpawnChangedEvent()
    {
        if (_currentTile != null && _currentArea != null)
        {
            FlagChanged?.Invoke(this, new TileSpawnChangedEventArgs(_currentTile, _currentArea));
        }
    }

    public List<AreaSpawnMonsterSubtype> MonsterSubtypes { get; private set; } = [];

    public List<Monster> Monsters { get; private set; } = [];

    private Monster? _lairedMonster;

    public Monster? LairedMonster
    {
        get => _lairedMonster;
        set => SetProperty(ref _lairedMonster, value);
    }

    public class AreaSpawnMonsterSubtype(string name, int monsterSubtypeId) : ObservableObject
    {
        public event EventHandler? SelectedChanged;

        public string Name { get; } = name;

        public int MonsterSubtypeId { get; } = monsterSubtypeId;

        private bool _selected;

        public bool Selected
        {
            get => _selected;
            set
            {
                SetProperty(ref _selected, value);
                SelectedChanged?.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
