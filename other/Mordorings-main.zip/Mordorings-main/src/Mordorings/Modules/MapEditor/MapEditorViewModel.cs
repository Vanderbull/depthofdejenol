﻿namespace Mordorings.Modules;

public partial class MapEditorViewModel : ViewModelBase
{
    private readonly IDialogFactory _dialogFactory;
    private readonly IMapEditorMediator _mapEditorMediator;

    public MapEditorViewModel(IMapEditorMediator mapEditorMediator, IDialogFactory dialogFactory)
    {
        _mapEditorMediator = mapEditorMediator;
        _dialogFactory = dialogFactory;
        _mapEditorMediator.Initialize();
        InitializeRenderers();
        SelectedFloorNum = 1;
        List<Monster> monsters = _mapEditorMediator.GetMonsters();
        List<MonsterSubtypeIndexed> subtypes = _mapEditorMediator.GetMonsterSubtypes();
        SpawnEditor.FlagChanged += UpdateTileSpawn;
        SpawnEditor.Initialize(monsters, subtypes);
    }

#region Properties

    private Tile? _selectedTile;

    private Tile? SelectedTile
    {
        get => _selectedTile;
        set
        {
            _selectedTile = value;
            OnPropertyChanged(nameof(TileX));
            OnPropertyChanged(nameof(TileY));
            OnPropertyChanged(nameof(AreaNum));
        }
    }

    public TilePropertyEditor PropertyEditor { get; } = new();

    public TileSpawnEditor SpawnEditor { get; } = new();

    public bool IsTileSelected => TileX is not null && TileY is not null;

    private IAutomapRenderer? CurrentRenderer
    {
        get
        {
            if (SelectedFloorNum is < Game.MinFloor or > Game.MaxFloor)
                return null;
            return _mapEditorMediator.Renderers[SelectedFloorNum - 1];
        }
    }

    private DungeonFloor SelectedFloor => _mapEditorMediator.DungeonFloors[SelectedFloorNum - 1];

    public int? TileX => SelectedTile?.X;

    public int? TileY => SelectedTile?.Y;

    public int? AreaNum => SelectedFloor.Floor.GetAreaNumFromTile(SelectedTile);

    private bool _isTileEditorSelected = true;

    public bool IsTileEditorSelected
    {
        get => _isTileEditorSelected;
        set
        {
            SetProperty(ref _isTileEditorSelected, value);
            if (!value)
                return;
            if (CurrentRenderer == null || SelectedTile == null)
                return;
            CurrentRenderer.RemoveHighlight();
            CurrentRenderer.HighlightTile(SelectedTile);
        }
    }

    private bool _isAreaSpawnEditorSelected;

    public bool IsAreaSpawnEditorSelected
    {
        get => _isAreaSpawnEditorSelected;
        set
        {
            SetProperty(ref _isAreaSpawnEditorSelected, value);
            if (!value)
                return;
            if (CurrentRenderer == null || SelectedTile == null)
                return;
            CurrentRenderer.HighlightArea(SelectedTile);
        }
    }

    private object? _image;

    public object? Image
    {
        get => _image;
        private set => SetProperty(ref _image, value);
    }

    private int _selectedFloorNum;

    public int SelectedFloorNum
    {
        get => _selectedFloorNum;
        set
        {
            int oldValue = _selectedFloorNum;
            if (!SetProperty(ref _selectedFloorNum, value))
                return;
            HandleOnSelectedFloorNumChanged(oldValue, value);
            IncreaseFloorCommand.NotifyCanExecuteChanged();
            DecreaseFloorCommand.NotifyCanExecuteChanged();
        }
    }

    private List<MonsterSpawnRate>? _spawnRates;

    public List<MonsterSpawnRate>? SpawnRates
    {
        get => _spawnRates;
        private set => SetProperty(ref _spawnRates, value);
    }

#endregion

#region Relay Commands

    [RelayCommand(CanExecute = nameof(CanIncreaseFloor))]
    private void IncreaseFloor()
    {
        SelectedFloorNum += 1;
    }

    protected bool CanIncreaseFloor => SelectedFloorNum < Game.MaxFloor;

    [RelayCommand(CanExecute = nameof(CanDecreaseFloor))]
    private void DecreaseFloor()
    {
        SelectedFloorNum -= 1;
    }

    protected bool CanDecreaseFloor => SelectedFloorNum > Game.MinFloor;

    [RelayCommand]
    private void Save()
    {
        if (_dialogFactory.ShowYesNoQuestion("Do you want to write your changes to the dungeon file?", "Save all"))
        {
            _mapEditorMediator.SaveAll();
        }
    }

    [RelayCommand]
    private void GetImageMouseClick(object? args)
    {
        Tile tile = AutomapEventConversion.GetMapCoordinatesFromEvent(args);
        if (tile.X is < 0 or >= Game.FloorWidth || tile.Y is < 0 or >= Game.FloorHeight)
        {
            SelectedTile = null;
            return;
        }
        SelectedTile = tile;
        PropertyEditor.FlagChanged -= UpdateTileProperties;
        CurrentRenderer?.DrawDungeonFloorMap();
        PropertyEditor.LoadTile(SelectedTile, SelectedFloor);
        SpawnEditor.LoadTile(SelectedTile, SelectedFloor);
        if (IsTileEditorSelected)
        {
            CurrentRenderer?.HighlightTile(SelectedTile);
        }
        else
        {
            CurrentRenderer?.HighlightArea(SelectedTile);
        }
        PropertyEditor.FlagChanged += UpdateTileProperties;
        OnPropertyChanged(nameof(IsTileSelected));
    }

#endregion

    private void GetImage(object? sender, EventArgs e)
    {
        if (sender is IAutomapRenderer iRenderer)
        {
            Image = iRenderer.GetMapSnapshot()?.ToBitmapSource();
        }
    }

    private void UpdateTileProperties(object? sender, TileFlagChangedEventArgs e)
    {
        DungeonTileFlag flags = e.AllFlags;
        MapObjects mapObjs = e.MapObjects;
        Tile tile = e.Tile;
        ProcessTeleporterChange(flags.HasFlag(DungeonTileFlag.Teleporter), tile, mapObjs);
        ProcessChuteChange(flags.HasFlag(DungeonTileFlag.Chute), tile, mapObjs.ChuteDepth);
        CurrentRenderer?.UpdateTile(tile, flags);
    }

    private void UpdateTileSpawn(object? sender, TileSpawnChangedEventArgs args)
    {
        Area? area = SelectedFloor.Floor.GetAreaFromTile(args.Tile);
        if (area == null)
            return;
        area.LairId = args.Area.LairId;
        area.SpawnMask = args.Area.SpawnMask;
        SpawnRates = area.SpawnMask != 0 ? _mapEditorMediator.GetSpawnsForTile(args.Tile, SelectedFloorNum) : null;
    }

    private void InitializeRenderers()
    {
        foreach (IAutomapRenderer renderer in _mapEditorMediator.Renderers)
        {
            renderer.MapUpdated += GetImage;
        }
    }

    private void ProcessTeleporterChange(bool addTeleporter, Tile tile, MapObjects mapObjects)
    {
        var teleporter = new TeleporterObject(mapObjects.TeleporterRandom, mapObjects.TeleporterX, mapObjects.TeleporterY, mapObjects.TeleporterZ);
        if (_mapEditorMediator.SaveTeleporter(tile, SelectedFloorNum, addTeleporter, teleporter))
            return;
        _dialogFactory.ShowErrorMessage("Unable to save teleporter. Only 20 teleporters are allowed per floor.", "Error");
        PropertyEditor.Teleporter = false;
    }

    private void ProcessChuteChange(bool addChute, Tile tile, int chuteDepth)
    {
        if (_mapEditorMediator.SaveChute(tile, SelectedFloorNum, addChute, chuteDepth))
            return;
        _dialogFactory.ShowErrorMessage("Unable to save chute. Only 10 chutes are allowed per floor.", "Error");
        PropertyEditor.Chute = false;
    }

    private void HandleOnSelectedFloorNumChanged(int oldValue, int newValue)
    {
        if (newValue is < Game.MinFloor or > Game.MaxFloor)
        {
            int actualValue;
            if (oldValue is >= Game.MinFloor and <= Game.MaxFloor)
            {
                actualValue = oldValue;
            }
            else
            {
                actualValue = Math.Clamp(newValue, Game.MinFloor, Game.MaxFloor);
            }
            _selectedFloorNum = actualValue;
        }
        CurrentRenderer?.RemoveHighlight();
        PropertyEditor.Clear();
        SpawnRates = null;
        SelectedTile = null;
        OnPropertyChanged(nameof(IsTileSelected));
    }

    public override string Instructions => "Edit the dungeon map. Click on a tile to edit its properties.";
}
