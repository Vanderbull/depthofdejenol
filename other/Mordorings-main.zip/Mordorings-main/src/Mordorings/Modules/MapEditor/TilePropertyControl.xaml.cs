﻿namespace Mordorings.Modules;

public partial class TilePropertyControl
{
    public TilePropertyControl()
    {
        InitializeComponent();
    }
}
