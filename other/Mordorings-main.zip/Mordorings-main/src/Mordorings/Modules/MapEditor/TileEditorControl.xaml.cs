﻿namespace Mordorings.Modules;

public partial class TileEditorControl
{
    public TileEditorControl()
    {
        InitializeComponent();
    }
}
