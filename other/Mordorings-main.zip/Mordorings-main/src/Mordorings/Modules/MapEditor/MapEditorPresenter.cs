﻿namespace Mordorings.Modules;

public class MapEditorPresenter(IMordorIoFactory ioFactory, IMapRendererFactory mapRendererFactory) : IMapEditorMediator
{
    private const string SpriteSheetFile = "Assets/DungeonSprites.bmp";

    private readonly MordorRecordReader _reader = ioFactory.GetReader();
    private readonly MordorRecordWriter _writer = ioFactory.GetWriter();
    private DATA11DungeonMap? _map;

    public DungeonFloor[] DungeonFloors { get; private set; } = [];

    public IAutomapRenderer[] Renderers { get; private set; } = [];

    public void Initialize()
    {
        _map = _reader.GetMordorRecord<DATA11DungeonMap>();
        int floorCount = _map.Floors.Length;
        DungeonFloors = new DungeonFloor[floorCount];
        Renderers = new IAutomapRenderer[floorCount];
        Floor[] floors = _map.Floors;
        for (int i = 0; i < floors.Length; i++)
        {
            var dungeonFloor = new DungeonFloor(floors[i]);
            DungeonFloors[i] = dungeonFloor;
            IAutomapRenderer renderer = mapRendererFactory.CreateAutomapRenderer();
            renderer.LoadSpriteSheet(SpriteSheetFile);
            renderer.Initialize(dungeonFloor);
            renderer.DrawDungeonFloorMap();
            Renderers[i] = renderer;
        }
    }

    public List<Monster> GetMonsters() => _reader.GetMordorRecord<DATA05Monsters>().MonstersList.ToList();

    public List<MonsterSubtypeIndexed> GetMonsterSubtypes() => _reader.GetMordorRecord<DATA01GameData>().GetIndexedMonsterSubtypes().ToList();

    public List<MonsterSpawnRate> GetSpawnsForTile(Tile tile, int floorNum)
    {
        if (_map == null)
            return [];
        var spawning = new MonsterSpawning(_reader.GetMordorRecord<DATA01GameData>(), _reader.GetMordorRecord<DATA05Monsters>(), _map);
        return spawning.GetExpectedMonsterSpawnProbabilities(tile.X + 1, tile.Y + 1, floorNum, false);
    }

    public bool SaveTeleporter(Tile tile, int floorNum, bool addTeleporter, TeleporterObject teleporter)
    {
        if (!addTeleporter)
        {
            DungeonFloors[floorNum - 1].DeleteTeleporter(tile);
        }
        else
        {
            int x2;
            int y2;
            int z2;
            if (teleporter.Random)
            {
                x2 = 0;
                y2 = 0;
                z2 = 0;
            }
            else
            {
                if (teleporter is not { X: not null, Y: not null, Z: not null })
                    return true;
                z2 = teleporter.Z.Value;
                x2 = teleporter.X.Value;
                y2 = teleporter.Y.Value;
            }
            return DungeonFloors[floorNum - 1].SaveTeleporter(tile, x2, y2, z2);
        }
        return true;
    }

    public bool SaveChute(Tile tile, int floorNum, bool addChute, int chuteDepth)
    {
        if (addChute)
            return DungeonFloors[floorNum - 1].SaveChute(tile, chuteDepth);
        DungeonFloors[floorNum - 1].DeleteChute(tile);
        return true;
    }

    public void SaveAll()
    {
        if (_map == null)
            return;
        for (int i = 0; i < DungeonFloors.Length; i++)
        {
            _map.Floors[i] = DungeonFloors[i].Floor;
        }
        _writer.WriteMordorRecord(_map);
    }
}
