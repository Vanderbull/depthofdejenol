﻿namespace Mordorings.Modules;

public partial class MapEditorControl
{
    public MapEditorControl()
    {
        InitializeComponent();
    }
}
