﻿namespace Mordorings.Modules;

public interface IMapEditorMediator
{
    /// <summary>
    /// Initializes map data and pre-renders all floors.
    /// </summary>
    void Initialize();

    /// <summary>
    /// Gets all cached dungeon floors (one per floor) used for editing.
    /// </summary>
    DungeonFloor[] DungeonFloors { get; }

    /// <summary>
    /// Gets all automap renderers (one per floor) that are initialized and drawn.
    /// </summary>
    IAutomapRenderer[] Renderers { get; }

    /// <summary>
    /// Writes all cached floors back to the underlying map file.
    /// </summary>
    void SaveAll();

    List<Monster> GetMonsters();

    List<MonsterSubtypeIndexed> GetMonsterSubtypes();

    bool SaveTeleporter(Tile tile, int floorNum, bool hasTeleporter, TeleporterObject teleporter);

    bool SaveChute(Tile tile, int floorNum, bool addChute, int chuteDepth);

    List<MonsterSpawnRate> GetSpawnsForTile(Tile tile, int floorNum);
}
