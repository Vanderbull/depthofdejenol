﻿namespace Mordorings.Modules;

public partial class TileAreaSpawnControl
{
    public TileAreaSpawnControl()
    {
        InitializeComponent();
    }
}
