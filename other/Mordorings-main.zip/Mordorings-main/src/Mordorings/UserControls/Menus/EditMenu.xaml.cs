﻿namespace Mordorings.UserControls;

public partial class EditMenu
{
    public EditMenu()
    {
        InitializeComponent();
    }
}
