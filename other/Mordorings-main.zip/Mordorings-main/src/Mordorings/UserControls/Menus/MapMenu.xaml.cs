﻿namespace Mordorings.UserControls;

public partial class MapMenu
{
    public MapMenu()
    {
        InitializeComponent();
    }
}
