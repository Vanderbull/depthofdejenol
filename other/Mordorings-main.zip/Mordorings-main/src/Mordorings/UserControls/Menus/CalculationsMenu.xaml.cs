﻿namespace Mordorings.UserControls;

public partial class CalculationsMenu
{
    public CalculationsMenu()
    {
        InitializeComponent();
    }
}
