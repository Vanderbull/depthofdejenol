﻿namespace Mordorings.Models;

public static class Game
{
    public const int MinFloor = 1;
    public const int MaxFloor = 15;
    public const int FloorWidth = 30;
    public const int FloorHeight = 30;
}
