﻿namespace Mordorings.Controls;

public class HeatMapRenderer : MapRendererBase, IHeatMapRenderer
{
    public void Render(MonsterHeatMapFloor? floor)
    {
        if (floor == null)
            return;
        ReplaceBitmap(floor.Map);
        foreach (AreaSpawnChance spawnRate in floor.SpawnRates)
        {
            for (int x = 0; x < Game.FloorWidth; x++)
            {
                for (int y = 0; y < Game.FloorHeight; y++)
                {
                    var tile = new Tile(x, y);
                    if (floor.DungeonFloor.GetAreaNumFromTile(tile) != spawnRate.AreaNum)
                        continue;
                    Color color = ProbabilityToColor(spawnRate.SpawnChance);
                    DrawRectangleOnTile(tile, color);
                }
            }
        }
    }

    private static Color ProbabilityToColor(double probability)
    {
        if (probability == 0)
            return Color.FromArgb(0, Color.Transparent);
        double scaled = Math.Sqrt(probability);
        int i = (int)(scaled * 255);
        int alpha = (int)(scaled * 175);
        return Color.FromArgb(Math.Max(alpha, 75), 255, 255 - i, 255 - i);
    }
}
