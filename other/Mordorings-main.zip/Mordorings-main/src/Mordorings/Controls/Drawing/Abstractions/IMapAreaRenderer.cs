﻿namespace Mordorings.Controls;

public interface IMapAreaRenderer
{

}
