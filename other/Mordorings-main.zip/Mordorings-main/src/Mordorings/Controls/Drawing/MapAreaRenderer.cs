﻿namespace Mordorings.Controls;

public class MapAreaRenderer : MapRendererBase, IMapAreaRenderer
{

}
