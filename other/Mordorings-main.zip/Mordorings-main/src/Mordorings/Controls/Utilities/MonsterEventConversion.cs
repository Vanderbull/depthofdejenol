﻿using System.Windows;

namespace Mordorings.Controls;

public static class MonsterEventConversion
{
    public static Monster? GetMonsterFromEvent(object? eventParameter)
    {
        if (eventParameter is not RoutedPropertyChangedEventArgs<object> args)
            return null;
        return args.NewValue as Monster;
    }
}
