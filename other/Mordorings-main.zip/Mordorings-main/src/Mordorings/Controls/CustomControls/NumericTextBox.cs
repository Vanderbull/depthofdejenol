﻿using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Mordorings.Controls;

public partial class NumericTextBox : TextBox
{
    public static readonly DependencyProperty MinValueProperty =
        DependencyProperty.Register(nameof(MinValue), typeof(int?), typeof(NumericTextBox), new PropertyMetadata(null));

    public int? MinValue
    {
        get => (int?)GetValue(MinValueProperty);
        set => SetValue(MinValueProperty, value);
    }

    public static readonly DependencyProperty MaxValueProperty =
        DependencyProperty.Register(nameof(MaxValue), typeof(int?), typeof(NumericTextBox), new PropertyMetadata(null));

    public int? MaxValue
    {
        get => (int?)GetValue(MaxValueProperty);
        set => SetValue(MaxValueProperty, value);
    }

    public static readonly DependencyProperty AllowPasteProperty =
        DependencyProperty.Register(nameof(AllowPaste), typeof(bool), typeof(NumericTextBox), new PropertyMetadata(false));

    public bool AllowPaste
    {
        get => (bool)GetValue(AllowPasteProperty);
        set => SetValue(AllowPasteProperty, value);
    }

    public NumericTextBox()
    {
        PreviewTextInput += OnPreviewTextInput;
        TextChanged += OnTextChanged;
        LostFocus += OnLostFocus;
        DataObject.AddPastingHandler(this, OnPaste);
    }

    private void OnPreviewTextInput(object sender, TextCompositionEventArgs e)
    {
        e.Handled = !ValidateInput(e.Text);
    }

    private void OnTextChanged(object sender, TextChangedEventArgs e)
    {
        int caretIndex = CaretIndex;
        string cleanedText = CheckForNumbers().Replace(Text, "");
        if (Text == cleanedText)
            return;
        Text = cleanedText;
        CaretIndex = Math.Min(caretIndex, cleanedText.Length);
    }

    private void OnLostFocus(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Text))
        {
            if (MinValue != null)
            {
                Text = MinValue.Value.ToString();
            }
            return;
        }
        if (!int.TryParse(Text, out int value))
            return;
        if (value < MinValue)
        {
            Text = MinValue.Value.ToString();
        }
        else if (value > MaxValue)
        {
            Text = MaxValue.Value.ToString();
        }
    }

    private void OnPaste(object sender, DataObjectPastingEventArgs e)
    {
        if (!AllowPaste)
        {
            e.CancelCommand();
            return;
        }
        if (!e.DataObject.GetDataPresent(typeof(string)))
            return;
        string? pastedText = (string?)e.DataObject.GetData(typeof(string));
        if (pastedText == null)
            return;
        string numericText = CheckForNumbers().Replace(pastedText, "");
        if (pastedText == numericText && !ValidateInput(pastedText))
            return;
        e.CancelCommand();
        if (string.IsNullOrEmpty(numericText))
            return;
        int caretIndex = CaretIndex;
        int selectionLength = SelectionLength;
        string currentText = Text;
        string beforeSelection = currentText.Substring(0, caretIndex);
        string afterSelection = currentText.Substring(caretIndex + selectionLength);
        Text = beforeSelection + numericText + afterSelection;
        CaretIndex = caretIndex + numericText.Length;
    }

    private bool ValidateMinMax(string text)
    {
        if (MinValue is null && MaxValue is null)
            return true;
        if (string.IsNullOrWhiteSpace(text))
            return true;
        int value = int.Parse(text);
        bool isInRange = true;
        if (MinValue != null)
        {
            isInRange = value >= MinValue;
        }
        if (MaxValue != null)
        {
            isInRange &= value <= MaxValue;
        }
        return isInRange;
    }

    private bool ValidateInput(string inputText)
    {
        string text;
        if (SelectedText.Length == Text.Length)
        {
            text = inputText;
        }
        else
        {
            text = Text + inputText;
        }
        return !string.IsNullOrEmpty(inputText) && inputText.All(char.IsDigit) && ValidateMinMax(text);
    }

    [GeneratedRegex("[^0-9]")]
    private static partial Regex CheckForNumbers();
}
