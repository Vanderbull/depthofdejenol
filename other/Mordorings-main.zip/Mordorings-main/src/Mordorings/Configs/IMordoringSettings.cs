﻿namespace Mordorings.Configs;

public interface IMordoringSettings
{
    string DataFileFolder { get; set; }
}
