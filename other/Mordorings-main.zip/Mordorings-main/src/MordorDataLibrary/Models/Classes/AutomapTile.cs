﻿namespace MordorDataLibrary.Models;

[UsedImplicitly(ImplicitUseTargetFlags.WithMembers)]
public class AutomapTile
{
    [NewRecord]
    public int Tile { get; set; }
}
