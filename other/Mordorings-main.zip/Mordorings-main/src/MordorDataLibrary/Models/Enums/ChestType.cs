﻿namespace MordorDataLibrary.Models;

[UsedImplicitly(ImplicitUseTargetFlags.WithMembers)]
public enum ChestType
{
    None = 0,
    Box = 2,
    Chest
}
