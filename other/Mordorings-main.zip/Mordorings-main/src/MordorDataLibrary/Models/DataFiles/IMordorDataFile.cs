﻿namespace MordorDataLibrary.Models;

public interface IMordorDataFile;
