﻿global using MordorDataLibrary.Data;
global using MordorDataLibrary.Models;
